# FITGENZ Flutter mini-project

## Build on GitHub Actions (phone-friendly)
1. Create a GitHub repository named `fitgenz`.
2. Upload `pubspec.yaml`, `lib/main.dart`, and `.github/workflows/build-apk.yml` preserving folder paths.
3. Open repository → Actions → Build FITGENZ APK → Run workflow.
4. Wait for the workflow to finish.
5. Open the completed run and download the `fitgenz-release-apk` artifact.
6. Extract the ZIP and install `app-release.apk` on your Android phone.

## Build locally
```bash
flutter pub get
flutter run
flutter build apk --release
```

The app uses SharedPreferences for local profile and progress persistence. It does not require Firebase or an AI API. Calculations are estimates for adults and should not be treated as medical advice. Review inputs and recommendations before demonstration.
